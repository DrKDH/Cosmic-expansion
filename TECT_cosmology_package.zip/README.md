
# Time-Energy Coupling Theory (TECT)

This repository provides the official implementation of the Time-Energy Coupling Theory (TECT) as described in the paper:

**Kang, D.** (2024). _Time-Energy Coupling Theory: An Integrated Solution to Cosmic Expansion and the Cosmological Constant Problem_.

---

## 📦 Installation

```bash
pip install -r requirements.txt
```

## ▶️ How to Run

```bash
python main.py
```

This will generate:

- `Table2_TECT_results.csv`: Numerical results for H(z), d_L(z), and chi-square values
- `figure1_energy_discrepancy.png`: Vacuum energy discrepancy visualization
- `figure2_Hz_comparison.png`: Hubble parameter comparison (TECT vs ΛCDM)
- `figure3_dL_TECT.png`: Luminosity distance prediction by TECT

---

## 📊 Model Features

- Spacetime volume derived from power-law time dynamics
- ODE-based cosmic expansion without cosmological constant
- Strong agreement with BAO and SN Ia observations
- Vacuum energy suppression ratio naturally recovered

---

## 📄 Paper Reference

Kang, D. (2024). *Time-Energy Coupling Theory: An Integrated Solution to Cosmic Expansion and the Cosmological Constant Problem*. Submitted to MDPI Mathematics.

---

## 🔗 Reproducibility

All numerical results in the paper can be reproduced using `main.py`.
