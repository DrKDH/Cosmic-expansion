
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import simpson

# Constants
c = 299792458
H0 = 67.4 * 1000 / (3.086e22)
Omega_m = 0.315
Omega_Lambda = 0.685
Mpc = 3.086e22
t0 = 13.787e9 * 365.25 * 24 * 3600
trec = 3.8e5 * 365.25 * 24 * 3600
a_rec = 1 / (1 + 1089)
alpha = 2.8

# Volume model
def V_model(t):
    return a_rec**3 + (1 - a_rec**3) * ((t**alpha - trec**alpha) / (t0**alpha - trec**alpha))

def t_of_z(z):
    a = 1 / (1 + z)
    Vt = a**3
    t_alpha = trec**alpha + (Vt - a_rec**3) * (t0**alpha - trec**alpha) / (1 - a_rec**3)
    return t_alpha**(1 / alpha)

def H_model(z):
    t = t_of_z(z)
    C = (1 - a_rec**3) * alpha / (t0**alpha - trec**alpha)
    dVdt = C * t**1.8
    return dVdt / (3 * V_model(t))

def d_L_model(z):
    zs = np.linspace(0, z, 300)
    Hz = np.array([H_model(zi) for zi in zs])
    integral = simpson(1 / Hz, zs)
    return (1 + z) * c * integral / Mpc

def generate_table2():
    z_points = [0.01, 0.1, 0.3, 0.7, 1.0]
    rows = []
    for z in z_points:
        H_LCDM_z = H0 * np.sqrt(Omega_m * (1 + z)**3 + Omega_Lambda)
        H_obs = H_LCDM_z * Mpc / 1000
        H_te = H_model(z) * Mpc / 1000
        dL_obs = (1 + z) * c * simpson(1 / (H0 * np.sqrt(Omega_m * (1 + np.linspace(0, z, 300)**3) + Omega_Lambda)), np.linspace(0, z, 300)) / Mpc
        dL_te = d_L_model(z)
        chi2_H = ((H_te - H_obs) / 5)**2
        chi2_d = ((dL_te - dL_obs) / (0.1 * dL_obs))**2
        rows.append([z, H_obs, H_te, dL_obs, dL_te, chi2_H, chi2_d])
    df = pd.DataFrame(rows, columns=[
        'z', 'H_obs (km/s/Mpc)', 'H_TECT (km/s/Mpc)',
        'dL_obs (Mpc)', 'dL_TECT (Mpc)', 'chi2_H', 'chi2_dL'
    ])
    df.to_csv("Table2_TECT_results.csv", index=False)
    print("Table 2 saved as Table2_TECT_results.csv")

def plot_figure1():
    labels = ["QFT Vacuum Energy", "Observed $\Lambda$ Energy"]
    values = [4.64e164, 5.84e-27]
    plt.figure()
    plt.bar(labels, values, log=True, color=["blue", "orange"])
    plt.ylabel("Energy Density (J/m³)")
    plt.title("Vacuum Energy Discrepancy")
    plt.tight_layout()
    plt.savefig("figure1_energy_discrepancy.png")
    plt.close()

def plot_figure2():
    zs = np.linspace(0, 2, 300)
    H_TECT = [H_model(z) * Mpc / 1000 for z in zs]
    H_LCDM = [H0 * np.sqrt(Omega_m * (1 + z)**3 + Omega_Lambda) * Mpc / 1000 for z in zs]
    plt.figure()
    plt.plot(zs, H_TECT, label="TECT")
    plt.plot(zs, H_LCDM, label="$\Lambda$CDM", linestyle="--")
    plt.xlabel("Redshift z")
    plt.ylabel("H(z) [km/s/Mpc]")
    plt.legend()
    plt.title("Comparison of H(z)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("figure2_Hz_comparison.png")
    plt.close()

def plot_figure3():
    zs = np.linspace(0, 2, 300)
    dL_TECT = [d_L_model(z) for z in zs]
    plt.figure()
    plt.plot(zs, dL_TECT, label="TECT Prediction")
    plt.xlabel("Redshift z")
    plt.ylabel("Luminosity Distance d_L(z) [Mpc]")
    plt.title("TECT Model Luminosity Distance")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("figure3_dL_TECT.png")
    plt.close()

if __name__ == "__main__":
    generate_table2()
    plot_figure1()
    plot_figure2()
    plot_figure3()
    print("All results generated: Table 2 and Figures 1–3.")
